package net.javaguides.springboot;

import net.javaguides.springboot.entity.User;

public class CurrentUser {
    public static User user;
}
